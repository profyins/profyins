/**
 * Base noise generator
 */
export default class Noise {
}
