import Simplex from "./simplex.js";
export default { Simplex };
