import Simple from "./simple.js";
import Speed from "./speed.js";
import Action from "./action.js";
export default { Simple, Speed, Action };
