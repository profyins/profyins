import Dijkstra from "./dijkstra.js";
import AStar from "./astar.js";
export default { Dijkstra, AStar };
